package com.scwang.smartrefresh.layout.listener;

/**
 * 刷新加载组合监听器
 * Created by SCWANG on 2017/5/26.
 */

public interface OnRefreshLoadmoreListener extends OnRefreshListener, OnLoadmoreListener{
}
