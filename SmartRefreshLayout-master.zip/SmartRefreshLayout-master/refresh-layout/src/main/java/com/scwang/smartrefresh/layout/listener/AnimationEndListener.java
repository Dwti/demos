package com.scwang.smartrefresh.layout.listener;

/**
 * 动画
 * Created by SCWANG on 2017/6/21.
 */

public interface AnimationEndListener {
    void onAnimationEnd();
}
