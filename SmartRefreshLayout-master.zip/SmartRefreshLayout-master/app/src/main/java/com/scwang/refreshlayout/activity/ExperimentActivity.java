package com.scwang.refreshlayout.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.scwang.refreshlayout.R;

public class ExperimentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_experiment);
    }
}
